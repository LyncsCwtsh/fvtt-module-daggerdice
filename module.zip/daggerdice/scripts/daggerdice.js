Hooks.on('diceSoNiceReady', (dice3d) => {
	
dice3d.addSystem({id:"bookish",name:"🗡️ Codex Pages"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/codex/d12-1.webp',
      'modules/daggerdice/faces/codex/d12-2.webp',
      'modules/daggerdice/faces/codex/d12-3.webp',
      'modules/daggerdice/faces/codex/d12-4.webp',
      'modules/daggerdice/faces/codex/d12-5.webp',
      'modules/daggerdice/faces/codex/d12-6.webp',
      'modules/daggerdice/faces/codex/d12-7.webp',
      'modules/daggerdice/faces/codex/d12-8.webp',
      'modules/daggerdice/faces/codex/d12-9.webp',
      'modules/daggerdice/faces/codex/d12-10.webp',
      'modules/daggerdice/faces/codex/d12-11.webp',
      'modules/daggerdice/faces/codex/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/codex/d12-1b.webp',
      'modules/daggerdice/faces/codex/d12-2b.webp',
      'modules/daggerdice/faces/codex/d12-3b.webp',
      'modules/daggerdice/faces/codex/d12-4b.webp',
      'modules/daggerdice/faces/codex/d12-5b.webp',
      'modules/daggerdice/faces/codex/d12-6b.webp',
      'modules/daggerdice/faces/codex/d12-7b.webp',
      'modules/daggerdice/faces/codex/d12-8b.webp',
      'modules/daggerdice/faces/codex/d12-9b.webp',
      'modules/daggerdice/faces/codex/d12-10b.webp',
      'modules/daggerdice/faces/codex/d12-11b.webp',
      'modules/daggerdice/faces/codex/d12-12b.webp'
	 ],
      system:"bookish"
  });
	
dice3d.addSystem({id:"bookishc",name:"🗡️ Codex Pages (Cutout)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/codex/cutout/d12-1.webp',
      'modules/daggerdice/faces/codex/cutout/d12-2.webp',
      'modules/daggerdice/faces/codex/cutout/d12-3.webp',
      'modules/daggerdice/faces/codex/cutout/d12-4.webp',
      'modules/daggerdice/faces/codex/cutout/d12-5.webp',
      'modules/daggerdice/faces/codex/cutout/d12-6.webp',
      'modules/daggerdice/faces/codex/cutout/d12-7.webp',
      'modules/daggerdice/faces/codex/cutout/d12-8.webp',
      'modules/daggerdice/faces/codex/cutout/d12-9.webp',
      'modules/daggerdice/faces/codex/cutout/d12-10.webp',
      'modules/daggerdice/faces/codex/cutout/d12-11.webp',
      'modules/daggerdice/faces/codex/cutout/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/codex/cutout/d12-1b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-2b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-3b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-4b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-5b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-6b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-7b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-8b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-9b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-10b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-11b.webp',
      'modules/daggerdice/faces/codex/cutout/d12-12b.webp'
	 ],
      system:"bookishc"
  });	
	
	
dice3d.addSystem({id:"bookishf",name:"🗡️ Codex Pages (Fill)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/codex/fill/d12-1.webp',
      'modules/daggerdice/faces/codex/fill/d12-2.webp',
      'modules/daggerdice/faces/codex/fill/d12-3.webp',
      'modules/daggerdice/faces/codex/fill/d12-4.webp',
      'modules/daggerdice/faces/codex/fill/d12-5.webp',
      'modules/daggerdice/faces/codex/fill/d12-6.webp',
      'modules/daggerdice/faces/codex/fill/d12-7.webp',
      'modules/daggerdice/faces/codex/fill/d12-8.webp',
      'modules/daggerdice/faces/codex/fill/d12-9.webp',
      'modules/daggerdice/faces/codex/fill/d12-10.webp',
      'modules/daggerdice/faces/codex/fill/d12-11.webp',
      'modules/daggerdice/faces/codex/fill/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/codex/d12-1b.webp',
      'modules/daggerdice/faces/codex/d12-2b.webp',
      'modules/daggerdice/faces/codex/d12-3b.webp',
      'modules/daggerdice/faces/codex/d12-4b.webp',
      'modules/daggerdice/faces/codex/d12-5b.webp',
      'modules/daggerdice/faces/codex/d12-6b.webp',
      'modules/daggerdice/faces/codex/d12-7b.webp',
      'modules/daggerdice/faces/codex/d12-8b.webp',
      'modules/daggerdice/faces/codex/d12-9b.webp',
      'modules/daggerdice/faces/codex/d12-10b.webp',
      'modules/daggerdice/faces/codex/d12-11b.webp',
      'modules/daggerdice/faces/codex/d12-12b.webp'
	 ],
      system:"bookishf"
  });		

dice3d.addSystem({id:"werefluff",name:"🗡️ Werefluff"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/werefluff/d12-1.webp',
      'modules/daggerdice/faces/werefluff/d12-2.webp',
      'modules/daggerdice/faces/werefluff/d12-3.webp',
      'modules/daggerdice/faces/werefluff/d12-4.webp',
      'modules/daggerdice/faces/werefluff/d12-5.webp',
      'modules/daggerdice/faces/werefluff/d12-6.webp',
      'modules/daggerdice/faces/werefluff/d12-7.webp',
      'modules/daggerdice/faces/werefluff/d12-8.webp',
      'modules/daggerdice/faces/werefluff/d12-9.webp',
      'modules/daggerdice/faces/werefluff/d12-10.webp',
      'modules/daggerdice/faces/werefluff/d12-11.webp',
      'modules/daggerdice/faces/werefluff/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/werefluff/d12-1b.webp',
      'modules/daggerdice/faces/werefluff/d12-2b.webp',
      'modules/daggerdice/faces/werefluff/d12-3b.webp',
      'modules/daggerdice/faces/werefluff/d12-4b.webp',
      'modules/daggerdice/faces/werefluff/d12-5b.webp',
      'modules/daggerdice/faces/werefluff/d12-6b.webp',
      'modules/daggerdice/faces/werefluff/d12-7b.webp',
      'modules/daggerdice/faces/werefluff/d12-8b.webp',
      'modules/daggerdice/faces/werefluff/d12-9b.webp',
      'modules/daggerdice/faces/werefluff/d12-10b.webp',
      'modules/daggerdice/faces/werefluff/d12-11b.webp',
      'modules/daggerdice/faces/werefluff/d12-12b.webp'
	 ],
      system:"werefluff"
  });
  
  dice3d.addSystem({id:"bloodied",name:"🗡️ Blood & Claws"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/werefluff/bloodied/d12-1.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-2.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-3.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-4.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-5.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-6.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-7.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-8.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-9.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-10.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-11.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/werefluff/bloodied/d12-1b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-2b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-3b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-4b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-5b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-6b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-7b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-8b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-9b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-10b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-11b.webp',
      'modules/daggerdice/faces/werefluff/bloodied/d12-12b.webp'
	 ],
      system:"bloodied"
  });
  

dice3d.addSystem({id:"h&f",name:"🗡️ Hope & Fear (Combo)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/hope&fear/d12-1.webp',
      'modules/daggerdice/faces/hope&fear/d12-2.webp',
      'modules/daggerdice/faces/hope&fear/d12-3.webp',
      'modules/daggerdice/faces/hope&fear/d12-4.webp',
      'modules/daggerdice/faces/hope&fear/d12-5.webp',
      'modules/daggerdice/faces/hope&fear/d12-6.webp',
      'modules/daggerdice/faces/hope&fear/d12-7.webp',
      'modules/daggerdice/faces/hope&fear/d12-8.webp',
      'modules/daggerdice/faces/hope&fear/d12-9.webp',
      'modules/daggerdice/faces/hope&fear/d12-10.webp',
      'modules/daggerdice/faces/hope&fear/d12-11.webp',
      'modules/daggerdice/faces/hope&fear/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/hope&fear/d12-1b.webp',
      'modules/daggerdice/faces/hope&fear/d12-2b.webp',
      'modules/daggerdice/faces/hope&fear/d12-3b.webp',
      'modules/daggerdice/faces/hope&fear/d12-4b.webp',
      'modules/daggerdice/faces/hope&fear/d12-5b.webp',
      'modules/daggerdice/faces/hope&fear/d12-6b.webp',
      'modules/daggerdice/faces/hope&fear/d12-7b.webp',
      'modules/daggerdice/faces/hope&fear/d12-8b.webp',
      'modules/daggerdice/faces/hope&fear/d12-9b.webp',
      'modules/daggerdice/faces/hope&fear/d12-10b.webp',
      'modules/daggerdice/faces/hope&fear/d12-11b.webp',
      'modules/daggerdice/faces/hope&fear/d12-12b.webp'
	 ],
      system:"h&f"
  });

dice3d.addSystem({id:"h&fv",name:"🗡️ Hope & Fear (Vermilion)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/hope&fear/vermilion/d12-1.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-2.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-3.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-4.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-5.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-6.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-7.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-8.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-9.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-10.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-11.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/hope&fear/d12-1b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-2b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-3b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-4b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-5b.webp',
      'modules/daggerdice/faces/hope&fear/d12-6b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-7b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-8b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-9b.webp',
      'modules/daggerdice/faces/hope&fear/vermilion/d12-10b.webp',
      'modules/daggerdice/faces/hope&fear/d12-11b.webp',
      'modules/daggerdice/faces/hope&fear/d12-12b.webp'
	 ],
      system:"h&fv"
  });

dice3d.addSystem({id:"h&fn",name:"🗡️ Hope & Fear (Nebula)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/hope&fear/nebula/d12-1.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-2.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-3.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-4.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-5.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-6.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-7.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-8.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-9.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-10.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-11.webp',
      'modules/daggerdice/faces/hope&fear/nebula/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/hope&fear/d12-1b.webp',
      'modules/daggerdice/faces/hope&fear/d12-2b.webp',
      'modules/daggerdice/faces/hope&fear/d12-3b.webp',
      'modules/daggerdice/faces/hope&fear/d12-4b.webp',
      'modules/daggerdice/faces/hope&fear/d12-5b.webp',
      'modules/daggerdice/faces/hope&fear/d12-6b.webp',
      'modules/daggerdice/faces/hope&fear/d12-7b.webp',
      'modules/daggerdice/faces/hope&fear/d12-8b.webp',
      'modules/daggerdice/faces/hope&fear/d12-9b.webp',
      'modules/daggerdice/faces/hope&fear/d12-10b.webp',
      'modules/daggerdice/faces/hope&fear/d12-11b.webp',
      'modules/daggerdice/faces/hope&fear/d12-12b.webp'
	 ],
      system:"h&fn"
  });


dice3d.addSystem({id:"arroweddark",name:"🗡️ Arrowed (Dark)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/arrowed/arroweddark/d12-1.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-2.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-3.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-4.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-5.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-6.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-7.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-8.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-9.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-10.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-11.webp',
      'modules/daggerdice/faces/arrowed/arroweddark/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/arrowed/d12-1b.webp',
      'modules/daggerdice/faces/arrowed/d12-2b.webp',
      'modules/daggerdice/faces/arrowed/d12-3b.webp',
      'modules/daggerdice/faces/arrowed/d12-4b.webp',
      'modules/daggerdice/faces/arrowed/d12-5b.webp',
      'modules/daggerdice/faces/arrowed/d12-6b.webp',
      'modules/daggerdice/faces/arrowed/d12-7b.webp',
      'modules/daggerdice/faces/arrowed/d12-8b.webp',
      'modules/daggerdice/faces/arrowed/d12-9b.webp',
      'modules/daggerdice/faces/arrowed/d12-10b.webp',
      'modules/daggerdice/faces/arrowed/d12-11b.webp',
      'modules/daggerdice/faces/arrowed/d12-12b.webp'
	 ],
      system:"arroweddark"
  });

 dice3d.addSystem({id:"arrowedlight",name:"🗡️ Arrowed (Light)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-1.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-2.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-3.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-4.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-5.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-6.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-7.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-8.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-9.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-10.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-11.webp',
      'modules/daggerdice/faces/arrowed/arrowedlight/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/arrowed/d12-1b.webp',
      'modules/daggerdice/faces/arrowed/d12-2b.webp',
      'modules/daggerdice/faces/arrowed/d12-3b.webp',
      'modules/daggerdice/faces/arrowed/d12-4b.webp',
      'modules/daggerdice/faces/arrowed/d12-5b.webp',
      'modules/daggerdice/faces/arrowed/d12-6b.webp',
      'modules/daggerdice/faces/arrowed/d12-7b.webp',
      'modules/daggerdice/faces/arrowed/d12-8b.webp',
      'modules/daggerdice/faces/arrowed/d12-9b.webp',
      'modules/daggerdice/faces/arrowed/d12-10b.webp',
      'modules/daggerdice/faces/arrowed/d12-11b.webp',
      'modules/daggerdice/faces/arrowed/d12-12b.webp'
	 ],
      system:"arrowedlight"
  });

dice3d.addSystem({id:"knightglass2",name:"🗡️ Castle Knights (Light)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/knightglass/light/d12-1.webp',
      'modules/daggerdice/faces/knightglass/light/d12-2.webp',
      'modules/daggerdice/faces/knightglass/light/d12-3.webp',
      'modules/daggerdice/faces/knightglass/light/d12-4.webp',
      'modules/daggerdice/faces/knightglass/light/d12-5.webp',
      'modules/daggerdice/faces/knightglass/light/d12-6.webp',
      'modules/daggerdice/faces/knightglass/light/d12-7.webp',
      'modules/daggerdice/faces/knightglass/light/d12-8.webp',
      'modules/daggerdice/faces/knightglass/light/d12-9.webp',
      'modules/daggerdice/faces/knightglass/light/d12-10.webp',
      'modules/daggerdice/faces/knightglass/light/d12-11.webp',
      'modules/daggerdice/faces/knightglass/light/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/knightglass/d12-1b.webp',
      'modules/daggerdice/faces/knightglass/d12-2b.webp',
      'modules/daggerdice/faces/knightglass/d12-3b.webp',
      'modules/daggerdice/faces/knightglass/d12-4b.webp',
      'modules/daggerdice/faces/knightglass/d12-5b.webp',
      'modules/daggerdice/faces/knightglass/d12-6b.webp',
      'modules/daggerdice/faces/knightglass/d12-7b.webp',
      'modules/daggerdice/faces/knightglass/d12-8b.webp',
      'modules/daggerdice/faces/knightglass/d12-9b.webp',
      'modules/daggerdice/faces/knightglass/d12-10b.webp',
      'modules/daggerdice/faces/knightglass/d12-11b.webp',
      'modules/daggerdice/faces/knightglass/d12-12b.webp'
	 ],
      system:"knightglass2"
  });

dice3d.addSystem({id:"knightglass",name:"🗡️ Castle Knights (Dark)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/knightglass/d12-1.webp',
      'modules/daggerdice/faces/knightglass/d12-2.webp',
      'modules/daggerdice/faces/knightglass/d12-3.webp',
      'modules/daggerdice/faces/knightglass/d12-4.webp',
      'modules/daggerdice/faces/knightglass/d12-5.webp',
      'modules/daggerdice/faces/knightglass/d12-6.webp',
      'modules/daggerdice/faces/knightglass/d12-7.webp',
      'modules/daggerdice/faces/knightglass/d12-8.webp',
      'modules/daggerdice/faces/knightglass/d12-9.webp',
      'modules/daggerdice/faces/knightglass/d12-10.webp',
      'modules/daggerdice/faces/knightglass/d12-11.webp',
      'modules/daggerdice/faces/knightglass/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/knightglass/d12-1b.webp',
      'modules/daggerdice/faces/knightglass/d12-2b.webp',
      'modules/daggerdice/faces/knightglass/d12-3b.webp',
      'modules/daggerdice/faces/knightglass/d12-4b.webp',
      'modules/daggerdice/faces/knightglass/d12-5b.webp',
      'modules/daggerdice/faces/knightglass/d12-6b.webp',
      'modules/daggerdice/faces/knightglass/d12-7b.webp',
      'modules/daggerdice/faces/knightglass/d12-8b.webp',
      'modules/daggerdice/faces/knightglass/d12-9b.webp',
      'modules/daggerdice/faces/knightglass/d12-10b.webp',
      'modules/daggerdice/faces/knightglass/d12-11b.webp',
      'modules/daggerdice/faces/knightglass/d12-12b.webp'
	 ],
      system:"knightglass"
  });


 dice3d.addSystem({id:"thorns",name:"🗡️ Thorns"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/thorns/d12-1.webp',
      'modules/daggerdice/faces/thorns/d12-2.webp',
      'modules/daggerdice/faces/thorns/d12-3.webp',
      'modules/daggerdice/faces/thorns/d12-4.webp',
      'modules/daggerdice/faces/thorns/d12-5.webp',
      'modules/daggerdice/faces/thorns/d12-6.webp',
      'modules/daggerdice/faces/thorns/d12-7.webp',
      'modules/daggerdice/faces/thorns/d12-8.webp',
      'modules/daggerdice/faces/thorns/d12-9.webp',
      'modules/daggerdice/faces/thorns/d12-10.webp',
      'modules/daggerdice/faces/thorns/d12-11.webp',
      'modules/daggerdice/faces/thorns/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/thorns/d12-1b.webp',
      'modules/daggerdice/faces/thorns/d12-2b.webp',
      'modules/daggerdice/faces/thorns/d12-3b.webp',
      'modules/daggerdice/faces/thorns/d12-4b.webp',
      'modules/daggerdice/faces/thorns/d12-5b.webp',
      'modules/daggerdice/faces/thorns/d12-6b.webp',
      'modules/daggerdice/faces/thorns/d12-7b.webp',
      'modules/daggerdice/faces/thorns/d12-8b.webp',
      'modules/daggerdice/faces/thorns/d12-9b.webp',
      'modules/daggerdice/faces/thorns/d12-10b.webp',
      'modules/daggerdice/faces/thorns/d12-11b.webp',
      'modules/daggerdice/faces/thorns/d12-12b.webp'
	 ],
      system:"thorns"
  });

  dice3d.addSystem({id:"runew",name:"🗡️ Runic Warrior"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/runicwarrior/d12-1.webp',
      'modules/daggerdice/faces/runicwarrior/d12-2.webp',
      'modules/daggerdice/faces/runicwarrior/d12-3.webp',
      'modules/daggerdice/faces/runicwarrior/d12-4.webp',
      'modules/daggerdice/faces/runicwarrior/d12-5.webp',
      'modules/daggerdice/faces/runicwarrior/d12-6.webp',
      'modules/daggerdice/faces/runicwarrior/d12-7.webp',
      'modules/daggerdice/faces/runicwarrior/d12-8.webp',
      'modules/daggerdice/faces/runicwarrior/d12-9.webp',
      'modules/daggerdice/faces/runicwarrior/d12-10.webp',
      'modules/daggerdice/faces/runicwarrior/d12-11.webp',
      'modules/daggerdice/faces/runicwarrior/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/runicwarrior/d12-1b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-2b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-3b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-4b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-5b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-6b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-7b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-8b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-9b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-10b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-11b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-12b.webp'
	 ],
      system:"runew"
  });

  dice3d.addSystem({id:"runewf",name:"🗡️ Runic Warrior (Fill)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/runicwarrior/fill/d12-1.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-2.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-3.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-4.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-5.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-6.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-7.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-8.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-9.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-10.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-11.webp',
      'modules/daggerdice/faces/runicwarrior/fill/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/runicwarrior/d12-1b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-2b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-3b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-4b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-5b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-6b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-7b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-8b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-9b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-10b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-11b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-12b.webp'
	 ],
      system:"runewf"
  });

  dice3d.addSystem({id:"runewc",name:"🗡️ Runic Warrior (Cutout)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/runicwarrior/cutout/d12-1.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-2.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-3.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-4.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-5.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-6.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-7.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-8.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-9.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-10.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-11.webp',
      'modules/daggerdice/faces/runicwarrior/cutout/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/runicwarrior/d12-1b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-2b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-3b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-4b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-5b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-6b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-7b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-8b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-9b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-10b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-11b.webp',
      'modules/daggerdice/faces/runicwarrior/d12-12b.webp'
	 ],
      system:"runewc"
  });

 dice3d.addSystem({id:"sundown",name:"🗡️ Sundown"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/sundown/d12-1.webp',
      'modules/daggerdice/faces/sundown/d12-2.webp',
      'modules/daggerdice/faces/sundown/d12-3.webp',
      'modules/daggerdice/faces/sundown/d12-4.webp',
      'modules/daggerdice/faces/sundown/d12-5.webp',
      'modules/daggerdice/faces/sundown/d12-6.webp',
      'modules/daggerdice/faces/sundown/d12-7.webp',
      'modules/daggerdice/faces/sundown/d12-8.webp',
      'modules/daggerdice/faces/sundown/d12-9.webp',
      'modules/daggerdice/faces/sundown/d12-10.webp',
      'modules/daggerdice/faces/sundown/d12-11.webp',
      'modules/daggerdice/faces/sundown/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/sundown/d12-1b.webp',
      'modules/daggerdice/faces/sundown/d12-2b.webp',
      'modules/daggerdice/faces/sundown/d12-3b.webp',
      'modules/daggerdice/faces/sundown/d12-4b.webp',
      'modules/daggerdice/faces/sundown/d12-5b.webp',
      'modules/daggerdice/faces/sundown/d12-6b.webp',
      'modules/daggerdice/faces/sundown/d12-7b.webp',
      'modules/daggerdice/faces/sundown/d12-8b.webp',
      'modules/daggerdice/faces/sundown/d12-9b.webp',
      'modules/daggerdice/faces/sundown/d12-10b.webp',
      'modules/daggerdice/faces/sundown/d12-11b.webp',
      'modules/daggerdice/faces/sundown/d12-12b.webp'
	 ],
      system:"sundown"
  });

   dice3d.addSystem({id:"swordglass",name:"🗡️ 12 Swords till Midnight (Light)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/swordedglass/d12-1.webp',
      'modules/daggerdice/faces/swordedglass/d12-2.webp',
      'modules/daggerdice/faces/swordedglass/d12-3.webp',
      'modules/daggerdice/faces/swordedglass/d12-4.webp',
      'modules/daggerdice/faces/swordedglass/d12-5.webp',
      'modules/daggerdice/faces/swordedglass/d12-6.webp',
      'modules/daggerdice/faces/swordedglass/d12-7.webp',
      'modules/daggerdice/faces/swordedglass/d12-8.webp',
      'modules/daggerdice/faces/swordedglass/d12-9.webp',
      'modules/daggerdice/faces/swordedglass/d12-10.webp',
      'modules/daggerdice/faces/swordedglass/d12-11.webp',
      'modules/daggerdice/faces/swordedglass/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/swordedglass/d12-1b.webp',
      'modules/daggerdice/faces/swordedglass/d12-2b.webp',
      'modules/daggerdice/faces/swordedglass/d12-3b.webp',
      'modules/daggerdice/faces/swordedglass/d12-4b.webp',
      'modules/daggerdice/faces/swordedglass/d12-5b.webp',
      'modules/daggerdice/faces/swordedglass/d12-6b.webp',
      'modules/daggerdice/faces/swordedglass/d12-7b.webp',
      'modules/daggerdice/faces/swordedglass/d12-8b.webp',
      'modules/daggerdice/faces/swordedglass/d12-9b.webp',
      'modules/daggerdice/faces/swordedglass/d12-10b.webp',
      'modules/daggerdice/faces/swordedglass/d12-11b.webp',
      'modules/daggerdice/faces/swordedglass/d12-12b.webp'
	 ],
      system:"swordglass"
  });

   dice3d.addSystem({id:"swordglass2",name:"🗡️ 12 Swords till Midnight (Dark)"},false);

  dice3d.addDicePreset({
    type:"d12",
    labels:[
      'modules/daggerdice/faces/swordedglass/dark/d12-1.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-2.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-3.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-4.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-5.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-6.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-7.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-8.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-9.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-10.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-11.webp',
      'modules/daggerdice/faces/swordedglass/dark/d12-12.webp'
    ],
    bumpMaps:[
      'modules/daggerdice/faces/swordedglass/d12-1b.webp',
      'modules/daggerdice/faces/swordedglass/d12-2b.webp',
      'modules/daggerdice/faces/swordedglass/d12-3b.webp',
      'modules/daggerdice/faces/swordedglass/d12-4b.webp',
      'modules/daggerdice/faces/swordedglass/d12-5b.webp',
      'modules/daggerdice/faces/swordedglass/d12-6b.webp',
      'modules/daggerdice/faces/swordedglass/d12-7b.webp',
      'modules/daggerdice/faces/swordedglass/d12-8b.webp',
      'modules/daggerdice/faces/swordedglass/d12-9b.webp',
      'modules/daggerdice/faces/swordedglass/d12-10b.webp',
      'modules/daggerdice/faces/swordedglass/d12-11b.webp',
      'modules/daggerdice/faces/swordedglass/d12-12b.webp'
	 ],
      system:"swordglass2"
  });

dice3d.addColorset({
    name: 'rainbowalt',
    description: '🗡️ Pastel Rainbow',
    category: 'Colors',
    edge: [
        '#db606e',
        '#ed955c',
        '#e1c269',
        '#85c87d',
        '#709cd4',
        '#a85cd1'
    ],
    background: [
        '#db606e',
        '#ed955c',
        '#e1c269',
        '#85c87d',
        '#709cd4',
        '#a85cd1'
    ]
});

	dice3d.addTexture("rainbow", {
	    name: "🗡️ Rainbow",
	    composite: "difference",
	    source: "modules/daggerdice/textures/rainbow.webp"
	});

	dice3d.addTexture("greywolf", {
	    name: "🗡️ Greywolf",
	    composite: "difference",
	    source: "modules/daggerdice/textures/fur.webp"
	});

    dice3d.addTexture("lightpaintedplate", {
	    name: "🗡️ Painted Amber",
	    composite: "difference",
	    source: "modules/daggerdice/textures/lightpaintedplate.webp"
	});

    dice3d.addTexture("flame", {
	    name: "🗡️ Angy Flame",
	    composite: "difference",
	    source: "modules/daggerdice/textures/flame.webp"
	});

    dice3d.addTexture("purble", {
	    name: "🗡️ Purble",
	    composite: "difference",
	    source: "modules/daggerdice/textures/purble.webp"
	});
});
